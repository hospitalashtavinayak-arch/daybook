const storageKey = "avhs-daybook-v1";

export const modes = { account: "A/C", cash: "Cash", card: "Swipe Card" };
export const rowLimit = 60;

export function readEntries() {
  const entries = JSON.parse(localStorage.getItem(storageKey) ?? "[]");
  if (!Array.isArray(entries)) throw new Error("Invalid register data");
  return entries.map((entry, index) => ({
    ...entry, id: entry.id ?? `legacy-${index}`, service: entry.service ?? "", mode: entry.mode ?? ""
  }));
}

export function writeEntries(entries) {
  localStorage.setItem(storageKey, JSON.stringify(entries));
}
