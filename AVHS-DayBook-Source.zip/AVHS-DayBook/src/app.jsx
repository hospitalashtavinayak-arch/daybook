import React, { useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { modes, rowLimit, readEntries, writeEntries } from "./entries.js";

const money = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" });
const rupees = paise => money.format(paise / 100);
const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
function App() {
  const [initial] = useState(() => {
    try { return { entries: readEntries() }; }
    catch { return { entries: [], error: "Saved entries could not be loaded. Editing is disabled." }; }
  });
  const [entries, setEntries] = useState(initial.entries);
  const [date, setDate] = useState(today);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState("");
  const formRef = useRef(null);

  function startEdit(row, field) {
    setEditing(row.id);
    setError("");
    requestAnimationFrame(() => {
      const input = formRef.current?.elements.namedItem(field);
      input?.focus();
      if (input?.type === "text") input.select();
    });
  }
  const rows = entries.filter(entry => entry.date === date);
  const canAdd = Boolean(date) && rows.length < rowLimit && !initial.error;

  function persist(next) {
    try { writeEntries(next); }
    catch { setError("Changes could not be saved in this browser."); return false; }
    setEntries(next);
    setError("");
    return true;
  }

  function save(event) {
    event.preventDefault();
    if (initial.error || (!editing && !canAdd)) return;
    const data = new FormData(event.currentTarget);
    const receipt = data.get("receipt");
    const payment = data.get("payment");
    const particulars = data.get("particulars").trim();
    const mode = data.get("mode");
    const paise = Math.round(Number(receipt || payment) * 100);
    if (!particulars || Boolean(receipt) === Boolean(payment) || !Number.isSafeInteger(paise) || paise <= 0 || paise > 99999999999 || !Object.hasOwn(modes, mode)) {
      setError("Enter particulars, a payment mode and one valid receipt or payment amount.");
      return;
    }
    const entry = { id: editing ?? crypto.randomUUID(), date, particulars, service: data.get("service").trim(), mode, orderedBy: data.get("orderedBy").trim(), type: receipt ? "in" : "out", paise };
    const next = editing ? entries.map(row => row.id === editing ? entry : row) : [...entries, entry];
    if (persist(next)) {
      const wasEditing = Boolean(editing);
      setEditing(null);
      formRef.current.reset();
      if (!wasEditing) requestAnimationFrame(() => formRef.current?.elements.particulars?.focus());
    }
  }

  function remove(row) {
    if (window.confirm(`Delete “${row.particulars}” (${rupees(row.paise)})?`)) {
      if (persist(entries.filter(entry => entry.id !== row.id))) setEditing(null);
    }
  }

  function editor(row, index) {
    const amount = type => row?.type === type ? (row.paise / 100).toFixed(2) : "";
    const amountInput = (name, type) => <input name={name} aria-label={name} type="number" min="0.01" max="999999999.99" step="0.01" placeholder="0.00" defaultValue={amount(type)} />;
    return <tr key={row?.id ?? "new"} className="entry-row" onKeyDown={event => {
      if (event.key === "Escape") {
        if (row) setEditing(null);
        else formRef.current.reset();
        setError("");
      }
      if (event.key === "Backspace" && row && event.target.tagName === "INPUT" && event.target.value === "") {
        event.preventDefault();
        if (!event.repeat) remove(row);
      }
      if (event.key === "Enter" && event.target.tagName === "INPUT" && !event.nativeEvent.isComposing) {
        event.preventDefault();
        if (!event.repeat) formRef.current.requestSubmit();
      }
    }}>
      <td>{index + 1}</td>
      <td><input name="particulars" aria-label="Particulars" placeholder="Write particulars" maxLength={160} defaultValue={row?.particulars} required /></td>
      <td><input name="service" aria-label="Service name" placeholder="Service name" maxLength={100} defaultValue={row?.service} /></td>
      <td className="amount">{amountInput("receipt", "in")}</td>
      <td><select name="mode" aria-label="Mode of payment" required defaultValue={row?.mode ?? ""}>
        <option value="">Select mode</option>
        {Object.entries(modes).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
      </select></td>
      <td className="amount">{amountInput("payment", "out")}</td>
      <td><input name="orderedBy" aria-label="Reported by" placeholder="Name" maxLength={100} defaultValue={row?.orderedBy} /></td>
    </tr>;
  }

  const totals = (mode) => {
    let receipt = 0;
    let payment = 0;
    for (const row of rows) {
      if (mode !== undefined && row.mode !== mode) continue;
      if (row.type === "in") receipt += row.paise;
      else payment += row.paise;
    }
    return [receipt, payment, receipt - payment];
  };
  const summary = [["Total amount", undefined], ...Object.entries(modes).map(([key, label]) => [label, key])];
  if (rows.some(row => !row.mode)) summary.push(["Unassigned", ""]);

  return <main className="shell mx-auto antialiased">
    <div className="brand uppercase">Ashtavinayak Multispeciality Hospital · Accounts</div>
    <article className="book relative">
      <header className="top">
        <h1>DayBook</h1>
        <label>Register date<input type="date" value={date} onChange={event => { setDate(event.target.value); setEditing(null); setError(""); }} /></label>
      </header>
      <div className="register-tools">
        <strong>{rows.length} / {rowLimit} entries</strong>
        <p className="muted">{editing ? "Enter to save · Esc to cancel" : canAdd ? "Enter to save" : date ? "Daily limit reached" : "Select a date"}</p>
      </div>
      <form ref={formRef} className="register-form" key={date} onSubmit={save}>
        {(initial.error || error) && <p role="alert" className="error">{initial.error || error}</p>}
        <div className="table-wrap overflow-x-auto" tabIndex={0} aria-label="DayBook entries">
          <table className="ledger"><thead><tr>{["S.No.", "Particulars", "Service Name", "Receipt (₹)", "Mode of Payment", "Payment (₹)", "Reported By"].map(label => <th key={label} scope="col">{label}</th>)}</tr></thead>
          <tbody>
            {rows.map((row, index) => {
              if (editing === row.id) return editor(row, index);
              const cells = [
                ["particulars", row.particulars],
                ["service", row.service || "—"],
                ["receipt", row.type === "in" ? rupees(row.paise) : ""],
                ["mode", modes[row.mode] ?? "Unassigned"],
                ["payment", row.type === "out" ? rupees(row.paise) : ""],
                ["orderedBy", row.orderedBy || "—"]
              ];
              return <tr key={row.id}><td>{index + 1}</td>{cells.map(([name, value]) =>
                <td key={name} className={name === "receipt" || name === "payment" ? "amount" : undefined}>
                  <span className="ledger-cell" role="button" tabIndex={editing ? -1 : 0}
                    aria-label={`Row ${index + 1}, ${name}: ${value || "empty"}. Edit cell.`}
                    onClick={() => { if (!editing) startEdit(row, name); }}
                    onKeyDown={event => {
                      if (editing || event.repeat) return;
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        startEdit(row, name);
                      }
                      if (event.key === "Backspace" || event.key === "Delete") {
                        event.preventDefault();
                        remove(row);
                      }
                    }}>{value}</span>
                </td>)}</tr>;
            })}
            {!editing && canAdd && editor(null, rows.length)}
            {Array.from({ length: Math.max(0, 5 - rows.length - Number(!editing && canAdd)) }, (_, index) =>
              <tr key={`blank-${index}`} aria-hidden="true">{Array.from({ length: 7 }, (_, column) => <td key={column} />)}</tr>)}
          </tbody></table>
        </div>
      </form>
      <section className="results" aria-label="Daily totals">
        <h2>Daily totals</h2>
        <div className="table-wrap"><table className="summary">
          <thead><tr>{["Mode", "Total Receipt", "Total Payment", "Net Amount"].map(label => <th scope="col" key={label}>{label}</th>)}</tr></thead>
          <tbody>{summary.map(([label, mode]) => <tr key={label}><th scope="row">{label}</th>{totals(mode).map((value, index) => <td key={index}>{rupees(value)}</td>)}</tr>)}</tbody>
        </table></div>
      </section>
    </article>
  </main>;
}

createRoot(document.getElementById("root")).render(<App />);
