CREATE TABLE entries (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL UNIQUE,
    business_date TEXT NOT NULL,
    particulars TEXT NOT NULL CHECK (length(trim(particulars)) BETWEEN 1 AND 160),
    service TEXT NOT NULL DEFAULT '' CHECK (length(service) <= 100),
    reported_by TEXT NOT NULL DEFAULT '' CHECK (length(reported_by) <= 100),
    mode TEXT NOT NULL CHECK (mode IN ('account', 'cash', 'card')),
    type TEXT NOT NULL CHECK (type IN ('in', 'out')),
    paise INTEGER NOT NULL CHECK (typeof(paise) = 'integer' AND paise BETWEEN 1 AND 99999999999),
    version INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    deleted_at TEXT
);

CREATE INDEX entries_day ON entries(business_date, seq) WHERE deleted_at IS NULL;

CREATE TRIGGER entries_daily_limit
BEFORE INSERT ON entries
WHEN (SELECT count(*) FROM entries WHERE business_date = NEW.business_date AND deleted_at IS NULL) >= 60
BEGIN
    SELECT RAISE(ABORT, 'daybook_daily_limit');
END;
