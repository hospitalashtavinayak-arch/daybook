# AVHS DayBook · FastAPI + Cloudflare D1

React DayBook → HTTPS FastAPI on Cloudflare Python Workers → D1 through the DB binding.

## Database design

| Field | Purpose |
|---|---|
| seq / id | Internal entry order / client-generated UUID |
| business_date | Register date in YYYY-MM-DD, chosen by staff in India |
| particulars / service / reported_by | Description, service and person who supplied the expense details |
| mode | account, cash or card |
| type / paise | in (receipt) or out (payment), with a positive integer in paise |
| version | Starts at 1 and prevents an older screen from overwriting a newer edit |
| created_at / updated_at / deleted_at | UTC timestamps, with soft deletion |

The migration limits each date to 60 active entries in the database itself. The displayed S.No. is calculated from the returned order. Totals are calculated from active entries for the selected date. Net = receipts − payments. Soft deletion retains the row, but this starter does not record individual staff identity or a full edit history.

## 1. Set up locally

Install Node.js and uv. Open a terminal in this folder. The project uses Python 3.13+.

```sh
uv python install 3.13
uv run pywrangler login
uv run pywrangler d1 create avhs-daybook
```

Copy the returned database ID into `wrangler.jsonc` in place of `REPLACE_WITH_D1_UUID`. Keep the binding name `DB`.

Copy `.dev.vars.example` to `.dev.vars`. Generate a random token using `uv run python -c "import secrets; print(secrets.token_urlsafe(32))"` and put it in `.dev.vars` as `DAYBOOK_TOKEN`. Do not commit this file.

```sh
uv run pywrangler d1 migrations apply avhs-daybook --local
uv run pywrangler dev
```

## 2. Test the API

Use curl (curl.exe on Windows) or Postman with the Authorization header `Bearer YOUR_LOCAL_TOKEN`.

| Method | Path | Body / parameters |
|---|---|---|
| GET | /api/entries?date=2026-11-06 | Returns entries, totals by mode, and row limit |
| POST | /api/entries | Entry fields, date and a new UUID |
| PUT | /api/entries/{id} | Entry fields and last-read version, without id or date |
| DELETE | /api/entries/{id}?version=1 | Last-read version, no body |

Create body example:

```json
{
  "id": "2f6c25be-042a-4dba-8975-692a7794b843",
  "date": "2026-11-06",
  "particulars": "DM Pharma medicine payment",
  "service": "Pharmacy",
  "reported_by": "Ravi Sir",
  "mode": "cash",
  "type": "out",
  "paise": 411200
}
```

For localhost, use `http://localhost:8787`. Check that GET shows Payment ₹4,112, Net −₹4,112 and a Cash total. PUT with version 1 should return version 2. A second PUT with version 1 should return 409. DELETE with version 2 should return 204 and remove the amount from GET totals. Reuse the same UUID if a POST outcome is uncertain. On 409, reload before retrying. Validation errors return 422, and unavailable database operations return 503.

## 3. Connect the existing React DayBook

Replace localStorage calls with an authenticated server-side integration. Serve React and its same-origin API gateway together, or use your existing authenticated hospital backend as the gateway. That gateway attaches the bearer token on its server-to-server call to this Worker. Keep the token out of React, browser storage and frontend build variables.

- Date change → GET the selected date. Render entries in API order.
- Add → generate a UUID with crypto.randomUUID(), then POST.
- Edit → PUT with the last-read version. Keep the form open on error.
- Delete → confirm, then DELETE with the last-read version.
- After any successful change, reload that date and use the returned totals.
- Map the current React field orderedBy to reported_by. Existing mode and type values match the API. Render paise / 100 as INR.
- Existing browser data stays local until explicitly imported. Export a copy, review legacy rows with missing payment mode, then import with stable UUIDs and reconcile totals date by date before switching screens.

## 4. Deploy to your Cloudflare account

```sh
uv run pywrangler d1 migrations apply avhs-daybook --remote
uv run pywrangler deploy
uv run pywrangler secret put DAYBOOK_TOKEN
```

Set a separate production token of at least 32 characters and configure it on the authenticated gateway. The Worker rejects requests until the token is configured. The shared token authenticates the gateway only. Enforce staff login and write permissions at the gateway before using this with hospital records.

## Official references

- https://developers.cloudflare.com/workers/languages/python/packages/fastapi/
- https://developers.cloudflare.com/d1/get-started/
