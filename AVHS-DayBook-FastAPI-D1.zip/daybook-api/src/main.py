from datetime import date
from secrets import compare_digest
from typing import Annotated, Literal
from uuid import UUID

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from pydantic import BaseModel, ConfigDict, Field
from workers import asgi

app = FastAPI(title="AVHS DayBook API", docs_url=None, redoc_url=None, openapi_url=None)
Default = asgi.entrypoint(app)
COLUMNS = """id, business_date AS date, particulars, service, reported_by,
             mode, type, paise, version, created_at, updated_at"""


class Entry(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    particulars: str = Field(min_length=1, max_length=160)
    service: str = Field(default="", max_length=100)
    reported_by: str = Field(default="", max_length=100)
    mode: Literal["account", "cash", "card"]
    type: Literal["in", "out"]
    paise: int = Field(strict=True, ge=1, le=99_999_999_999)

    def values(self):
        return (self.particulars, self.service, self.reported_by, self.mode, self.type, self.paise)


class CreateEntry(Entry):
    id: UUID
    date: date


class UpdateEntry(Entry):
    version: int = Field(strict=True, ge=1)


async def database(request: Request, authorization: Annotated[str | None, Header()] = None):
    env = request.scope["env"]
    token = str(getattr(env, "DAYBOOK_TOKEN", ""))
    if len(token) < 32:
        raise HTTPException(503, "API authentication is not configured")
    if not compare_digest((authorization or "").encode(), f"Bearer {token}".encode()):
        raise HTTPException(401, "Invalid credentials", headers={"WWW-Authenticate": "Bearer"})
    return env.DB


DB = Annotated[object, Depends(database)]


async def query(db, sql, *params):
    try:
        result = await db.prepare(sql).bind(*params).all()
        return result.results.to_py()
    except Exception as exc:
        if "daybook_daily_limit" in str(exc):
            raise HTTPException(409, "Daily limit of 60 entries reached") from exc
        raise HTTPException(503, "Database operation failed") from exc


@app.get("/api/entries")
async def list_entries(date: date, db: DB):
    rows = await query(db, f"""SELECT {COLUMNS} FROM entries
        WHERE business_date = ? AND deleted_at IS NULL ORDER BY seq""", date.isoformat())
    totals = {mode: {"receipt_paise": 0, "payment_paise": 0, "net_paise": 0}
              for mode in ("all", "account", "cash", "card")}
    for row in rows:
        key = "receipt_paise" if row["type"] == "in" else "payment_paise"
        for mode in ("all", row["mode"]):
            totals[mode][key] += row["paise"]
    for total in totals.values():
        total["net_paise"] = total["receipt_paise"] - total["payment_paise"]
    return {"entries": rows, "totals": totals, "limit": 60}


@app.post("/api/entries", status_code=201)
async def create_entry(entry: CreateEntry, db: DB):
    rows = await query(db, f"""INSERT INTO entries
        (id, business_date, particulars, service, reported_by, mode, type, paise)
        SELECT ?, ?, ?, ?, ?, ?, ?, ?
        WHERE NOT EXISTS (SELECT 1 FROM entries WHERE id = ?)
        RETURNING {COLUMNS}""", str(entry.id), entry.date.isoformat(), *entry.values(), str(entry.id))
    if not rows:
        raise HTTPException(409, "Entry ID already exists. Reload the register before retrying.")
    return rows[0]


@app.put("/api/entries/{entry_id}")
async def update_entry(entry_id: UUID, entry: UpdateEntry, db: DB):
    rows = await query(db, f"""UPDATE entries SET particulars = ?, service = ?, reported_by = ?,
        mode = ?, type = ?, paise = ?, version = version + 1,
        updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ? AND version = ? AND deleted_at IS NULL RETURNING {COLUMNS}""",
        *entry.values(), str(entry_id), entry.version)
    if not rows:
        raise HTTPException(409, "Entry changed or was deleted. Reload and retry.")
    return rows[0]


@app.delete("/api/entries/{entry_id}", status_code=204)
async def delete_entry(entry_id: UUID, version: Annotated[int, Query(ge=1)], db: DB):
    rows = await query(db, """UPDATE entries SET
        deleted_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'),
        updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), version = version + 1
        WHERE id = ? AND version = ? AND deleted_at IS NULL RETURNING id""", str(entry_id), version)
    if not rows:
        raise HTTPException(409, "Entry changed or was deleted. Reload and retry.")
